package mx.unam.aragon.ico.te.apiclientes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiclientesApplicationTests {

	@Test
	void contextLoads() {
	}

}
